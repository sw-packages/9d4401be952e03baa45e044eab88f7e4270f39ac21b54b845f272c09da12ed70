#ifndef __al_included_iphone_h
#define __al_included_iphone_h

void _al_iphone_acknowledge_drawing_halt(ALLEGRO_DISPLAY *display);

#endif
